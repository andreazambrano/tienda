<?php
// Heading
$_['heading_title'] = 'Category Feature';

// Text
$_['text_tax']      = 'Ex Tax:';