<?php
$_['text_qv_close'] = "<i class='fa fa-close'></i>";
// Text
$_['text_model']    = 'Product Code:';
$_['text_option']   = 'Available Options';