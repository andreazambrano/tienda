<?php
// Heading
$_['brand_heading_title'] = 'Brands';

